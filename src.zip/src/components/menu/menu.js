import menuImg from "../../clip-work-searches 1.png";

const Menu = () => {
  return (
    <>
      <img
        src={menuImg}
        className=""
        style={{ position: "absolute", bottom: "0", right: "0" }}
      />
    </>
  );
};

export default Menu;
